// ════════════════════════════════════════════════
//  舞萌DX 热门点歌榜 - 逻辑
// ════════════════════════════════════════════════

const $ = id => document.getElementById(id);

let scrollTimer = null;

async function poll() {
  try {
    const res = await fetch('/api/hot');
    const data = await res.json();
    renderHot(data.songs || []);
  } catch (e) {}
}

function renderHot(songs) {
  const topThree = $('topThree');
  const scrollList = $('scrollList');

  if (songs.length === 0) {
    topThree.innerHTML = '<div class="empty-hint">暂无点歌数据</div>';
    scrollList.classList.add('hidden');
    return;
  }

  const top3 = songs.slice(0, 3);
  const rest = songs.slice(3);

  topThree.innerHTML = '';
  const order = [top3[1], top3[0], top3[2]].filter(Boolean);
  const rankMap = [2, 1, 3];

  order.forEach((song, i) => {
    const rank = rankMap[i];
    if (!song) return;

    const card = document.createElement('div');
    card.className = `podium-card rank-${rank}`;

    let coverHtml;
    if (song.cover) {
      coverHtml = `<img class="podium-cover" src="/api/cover/${song.cover}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
        <div class="podium-cover-placeholder" style="display:none">♪</div>`;
    } else {
      coverHtml = '<div class="podium-cover-placeholder">♪</div>';
    }

    card.innerHTML = `
      <div class="podium-rank">${rank}</div>
      ${coverHtml}
      <div class="podium-title">${escapeHtml(song.title)}</div>
      <div class="podium-artist">${escapeHtml(song.artist || '')}</div>
      <div class="podium-count">${song.count} 次</div>
    `;

    topThree.appendChild(card);
  });

  if (rest.length > 0) {
    scrollList.classList.remove('hidden');
    renderScrollList(rest);
  } else {
    scrollList.classList.add('hidden');
  }
}

function renderScrollList(songs) {
  const track = $('scrollTrack');
  track.innerHTML = '';

  const items = [...songs, ...songs];

  items.forEach((song, i) => {
    const rank = (i % songs.length) + 4;

    const div = document.createElement('div');
    div.className = 'scroll-item';

    let coverHtml;
    if (song.cover) {
      coverHtml = `<img class="scroll-cover" src="/api/cover/${song.cover}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
        <div class="scroll-cover-placeholder" style="display:none">♪</div>`;
    } else {
      coverHtml = '<div class="scroll-cover-placeholder">♪</div>';
    }

    div.innerHTML = `
      <span class="scroll-rank">${rank}</span>
      ${coverHtml}
      <div class="scroll-info">
        <div class="scroll-title">${escapeHtml(song.title)}</div>
        <div class="scroll-artist">${escapeHtml(song.artist || '')}</div>
      </div>
      <span class="scroll-count">${song.count}</span>
    `;

    track.appendChild(div);
  });

  const itemHeight = 64;
  const gap = 8;
  const totalHeight = songs.length * (itemHeight + gap);

  if (scrollTimer) clearInterval(scrollTimer);

  let offset = 0;
  scrollTimer = setInterval(() => {
    offset += 1;
    if (offset >= totalHeight) {
      offset = 0;
    }
    track.style.transform = `translateY(-${offset}px)`;
  }, 40);
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

setInterval(poll, 10000);
poll();
